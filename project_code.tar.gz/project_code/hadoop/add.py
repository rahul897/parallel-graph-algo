from mrjob.job import MRJob

m = 2
n = 2
o = 3
p = 3
n = 2
alpha = .8

class MRWordFrequencyCount(MRJob):

    def mapper(self, _, line):
        line = line.split()
        if line[0]=="B":
            yield line[1]+","+line[2],line[3]+","+line[4]

    def reducer(self, key, values):
        result = 0
        for x in values:
            x = x.split(",")
            if int(x[1]) < n:
                result+=(1-alpha)*(alpha**int(x[1]))*float(x[0])
            else:
                result+=(alpha**n)*float(x[0])
        yield key, result


if __name__ == '__main__':
    MRWordFrequencyCount.run()
