#include <iostream>
#include <cstdlib>
using namespace std;

int main()
{
float HI=1,LO=-1;
for(int i=0;i<74984;i++)
	cout<<"A "<<rand()%1787<<" "<<rand()%3747<<" "<<LO + static_cast <float> (rand()) /( static_cast <float> (RAND_MAX/(HI-LO)))<<" "<<"0\n";
for(int i=0;i<74984;i++)
	cout<<"C "<<rand()%1787<<" "<<rand()%3747<<" "<<LO + static_cast <float> (rand()) /( static_cast <float> (RAND_MAX/(HI-LO)))<<" "<<"0\n";
for (int i = 0; i < 3747; ++i)
{
	for (int j = 0; j < 3747; ++j)
	{
		cout<<"B "<<i<<" "<<j<<" "<<1<<" "<<"0\n";
	}
}
}