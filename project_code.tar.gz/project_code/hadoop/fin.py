from mrjob.job import MRJob
from mrjob.protocol import RawValueProtocol 

m = 2
n = 2
o = 3
p = 3

class MRWordFrequencyCount(MRJob):
    OUTPUT_PROTOCOL = RawValueProtocol 

    def mapper(self, _, line):
        line = line.split()
        zelda = " ".join(line[0:4])
        if line[0]=="A":
            yield zelda+" "+str(int(line[4])+1),0
            for x in xrange(p):
                yield line[1]+",%d"%x,"A,"+line[2]+","+line[3]+","+line[4]
        elif line[0]=="B":
            for x in xrange(m):
                for y in xrange(p):
                    yield "%d,%d"%(x,y),"B,"+line[1]+","+line[2]+","+line[3]+","+line[4]
        else:
            yield zelda+" "+str(int(line[4])+1),0
            for y in xrange(m):
                yield "%d,"%y+line[2],"C,"+line[1]+","+line[3]+","+line[4]

    def reducer(self, key, values):
        if key[0]=="A" or key[0]=="C":
            yield None,key
        else :
            hA = {}
            hB = {}
            hC = {}
            t = 0
            for x in values:
                x = x.split(",")
                if x[0]=="A":
                    hA[int(x[1])]=float(x[2])
                elif x[0]=="B":
                    hB[x[1]+","+x[2]]=float(x[3])
                else:
                    hC[int(x[1])]=float(x[2])
                    t = int(x[3])+1
            result = 0
            for x in xrange(n):
                for y in xrange(o):
                    a_ij = hA[x]
                    b_jk = hB[str(x)+","+str(y)]
                    c_kl = hC[y]
                    result += a_ij*b_jk*c_kl
            zelda = key.split(",")
            yield None,"B "+zelda[0]+" "+zelda[1]+" "+str(result)+" "+str(t)


if __name__ == '__main__':
    MRWordFrequencyCount.run()
